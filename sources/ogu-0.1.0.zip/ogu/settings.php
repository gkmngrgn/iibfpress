<?php

$title = "İktisadi ve İdari Bilimler Fakültesi - Eskişehir Osmangazi Üniversitesi";
$charset = "UTF-8";

$url = "http://localhost/~gkmngrgn/iibf_web_page/ogu";

$currentUrl = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];

$cssDir = $url . "/css";
$jsDir = $url . "/js";
$imageDir = $url . "/images";

?>
