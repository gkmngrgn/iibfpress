<?php
function mainPage() {
    include('pages/mainpage.html');
}

function administration() {
    include('pages/administration.html');
}

function facmem() {
    include('pages/facmem.html');
}

function lessons() {
    include('pages/lessons.html');
}

function contact() {
    include('pages/contact.html');
}

function notices() {
    include('pages/notices.html');
}

function footer() {
    echo base64_decode('PC9kaXY+PC9kaXY+PC9kaXY+PC9kaXY+PGRpdiBjbGFzcz0iZm9vdGVyIj48cD5TaXRlIFRhc2FyxLFtOiA8YSBocmVmPSJodHRwOi8vd3d3Lmdva21lbmdvcmdlbi5uZXQiPkfDtmttZW4gR8O2cmdlbjwvYT4uIEJpcnRha8SxbSBoYWtsYXIgPGEgaHJlZj0iaHR0cDovL2NyZWF0aXZlY29tbW9ucy5vcmcvbGljZW5zZXMvYnktbmMtc2EvMi41LyI+c2FrbMSxZMSxcjwvYT4uPC9wPjwvZGl2Pg==');
}
?>
