<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset; ?>" />
<title><?php echo $title; ?></title>
<meta name="generator" content="iibfPress" />
<link rel="stylesheet" href="<?php echo $cssDir; ?>/style.css" type="text/css" media="screen" />

<script type="text/javascript" src="<?php echo $jsDir; ?>/jquery-1.2.6.min.js"></script>
<script type="text/javascript" src="<?php echo $jsDir; ?>/hmenu.js"></script>
<script type="text/javascript" src="<?php echo $jsDir; ?>/vmenu.js"></script>

<script language="JavaScript" type="text/javascript">
<!--
if  ((navigator.appName == "Microsoft Internet Explorer") && (navigator.userAgent.indexOf ("Opera") == -1)) {
    document.write ('<link href="<?php echo $cssDir; ?>/style_ie.css" rel="stylesheet" type="text/css" media="screen" />');
    };
//-->
</script>
</head>

<body>
    <div align="center" style="height:100%; width:100%; ">
        <div class="main_div">
            <div class="sub_main">
                <div class="table">
                    <div class="table_row">
