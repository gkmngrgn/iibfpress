<li><a href="<?php echo $url ?>/index.php?page=administration">Yönetim</a></li>
<li><a href="<?php echo $url ?>/index.php?page=facmem">Öğretim Üyeleri</a></li>
<li><a href="<?php echo $url; ?>/index.php?page=lessons">Dersler</a></li>
<li><a href="<?php echo $url ?>/index.php?page=contact">İletişim</a></li>
